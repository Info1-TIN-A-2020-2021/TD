/**
  \file      TD20201109a.c
  \brief     count keyboard input
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-09 15:10:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <math.h>

// main: entry point of the software
int main(int argc, char const *argv[]) {

  char c = 0;
  uint32_t cpt = 0;

  printf("Enter some chars: ");

  do {
    c = getchar();
    cpt++;

  } while (c != '\n');
  cpt--;

  printf("\ncpt=%u\n", cpt);
  puts("");
  return 0;
}

/**
  \file      TD20200929.c
  \brief     working with floats and doubles
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-09-29 15:10:00
  \details
    
**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdint.h> // library for standard types
#include <math.h>   // mathematic library

// main: entry point of the software
int main(int argc, char const *argv[])
{
  const double pi = 3.141592654;
  float f = 8.3f;
  double d = 8.3;

  // standard display with 6 digits after decimal point
  printf("f=%f\n", f);
  printf("d=%lf\n", d);

  // display with 10 digits after decimal point
  printf("f=%.10f\n", f);
  printf("d=%.10lf\n", d);

  // display with 20 digits after decimal point
  printf("f=%.20f\n", f);
  printf("d=%.20lf\n", d);

  // total width=6, with 2 digits after decimal point
  printf("d=%6.2lf\n", d);

  // total width=6, with 2 digits after decimal point and force the sign
  printf("d=%+6.2lf\n", d);

  //
  printf("d=%+6.2lf\n", 12020.346);

  // math operations => math.h
  d = 60.0;
  printf("cos=%lf\n", cos(d));                      // error, angle must be in radians
  printf("cos=%lf\n", cos(d * 3.141592654 / 180.)); // error, angle must be in radians
  printf("cos=%lf\n", cos(d * pi / 180.));          // using the pi constant

  // pi = 3.67; => not possible. Does not compile.

  return 0; // return code
}

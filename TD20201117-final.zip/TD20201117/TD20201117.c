/**
  \file      TD20201117.c
  \brief     1D table usage
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-17 14:55:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs
#include <math.h>

#define N 2000

int main(int argc, char const *argv[])
{
  double x[N];
  const double f = 1.;
  const double pi = 3.141592654;
  const double step = 0.001;
  uint32_t k = 0;
  double t = 0.;

  double max_value = 0.;
  uint32_t max_index = 0;

  double min_value = 0.;
  uint32_t min_index = 0;

  double sum=0.; // accumulator
  double mean=0.;

  printf("Size of x = %lu bytes.\n", sizeof(x));

  for (k = 0; k < N; k++) {
    // k : entier
    // step : double
    // k * step => promotion numérique de k en double => le résultat est un double.
    t = k * step;
    x[k] = sin(2. * pi * f * t);
  }
#if 0
  for (k = 0; k < N; k++) {
    printf("%4u  %+lf\n", k, x[k]);
  }
#endif

  // store the first value as the maximum and the related index
  max_index = 0;
  max_value = x[max_index];

  for (k = 1; k < N;k++) {
    if(x[k]>max_value) {
      max_value = x[k];
      max_index = k;
    }
  }
  printf("max value = %lf at index = %u\n", max_value, max_index);

  // store the first value as the minimum and the related index
  min_index = 0;
  min_value = x[min_index];

  for (k = 1; k < N;k++) {
    if(x[k]<min_value) {
      min_value = x[k];
      min_index = k;
    }
  }
  printf("min value = %lf at index = %u\n", min_value, min_index);

  // compute the mean value of the table
  // need one variable for the sum and one another for the mean value
  sum=0.;
  for(k=0;k<N;k++) {
    sum += x[k];
  }
  mean = sum / N;
  printf("mean value = %lf\n", mean);

  return 0;
}

/**
  \file      TD20201102.c
  \brief     controle structure switch/case
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-10-12 15:10:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs

// main: entry point of the software
int main(int argc, char const *argv[]) {
#if 0
  const double a = 3.14;
  const double b = 2.718;

  int32_t choice = 0;
  int ret = 0;

  puts("Menu\n");
  puts("0. end");
  puts("1. sum of a and b");
  puts("2. product of a and b");
  printf("\nYour choice: ");

  ret = scanf("%d", &choice);

  if(ret==1) {
    switch(choice) { // choice => integer only
      case 0:        // if(choice==0)...
        break;
      case 1:        // if(choice==1)...
        printf("sum = %6.2lf\n", a + b);
        break;
      case 2:        // if(choice==2)...
        printf("product = %6.2lf\n", a * b);
        break;
      default:      // other values
        break;
      }
  }
  else {
        puts("Bad choice");
  }
#elif 0

  char choice = ' ';

  printf("Is the sky blue ? ");
  choice = getchar();       // equ. scanf("%c", &choice);

  switch(choice) {
    case 'y':
    case 'Y':   // if(choice=='y' || choice=='Y')...
      puts("YES");
      break;

    case 'n':
    case 'N':
      puts("NO");
      break;
    default:
      break;
    }
#else
  uint32_t numCats = 0;
  int ret = 0;
  int a = 0;

  printf("Enter the number of cats: ");
  ret = scanf("%u", &numCats);

  printf("%u cat%s.\n", numCats, numCats>1 ? "s":"");

  a = numCats > 1 ? 1 : 0;

#endif

  return 0;
}

/**
  \file      TD20201207.c
  \brief     rotation matrix
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-30 14:55:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs
#include <math.h>

#define M 2
#define N 2

// mulmat prototype
void mulmat(const double m[M][N], const double a[M], double b[M]);


// double m[][N] => m est un tableau, je ne spécifie pas le nombre le ligne
//                  chaque ligne contient N colonnes
// double a[] => a est un tableau à une dimension, , je ne spécifie pas le nombre le ligne
// void mulmat2(const double m[][N], const double a[], double b[], const uint32_t num_rows);
// appel depuis le main:   mulmat2(m,a,b, 2);

// mulmat implementation
void mulmat(const double m[M][N],const double a[M], double b[M]) {

  //b[0]=m[0][0]*a[0]+m[0][1]*a[1]; // line=0
  //b[1]=m[1][0]*a[0]+m[1][1]*a[1]; // line=1
  
  // generalization
  uint32_t l=0;
  uint32_t c=0;

  for(l=0;l<M;l++) {
    b[l]=0.; // accumulator = 0
    for(c=0;c<N;c++) {
      b[l] += m[l][c]*a[c];
    }
  }
  
  return;
}


int main(int argc, char const *argv[])
{
  const int NO_ERROR = 0;
  int return_code = NO_ERROR;

  double xa = 1.0;
  double ya = 0.0;
  double alpha = 45.;
  double alpha_rad = alpha / 180 * 3.141592654;
  double xb = 0.;
  double yb = 0.;

  double a[M] = {0,0};
  double b[M] = {0,0};
  double m[M][N] = {
      {0,0},
      {0,0}
  };

  printf("xa=%+6.3lf ya=%+6.3lf\n", xa, ya);
  xb = xa * cos(alpha_rad) - ya * sin(alpha_rad);
  yb = xa * sin(alpha_rad) + ya * cos(alpha_rad);
  printf("xb=%+6.3lf yb=%+6.3lf\n", xb, yb);

  a[0] = xa;
  a[1] = ya;
  m[0][0] = cos(alpha_rad);  // ligne 1, col 1
  m[0][1] = -sin(alpha_rad); // ligne 1, col 2
  m[1][0] = sin(alpha_rad);  // ligne 2, col 1
  m[1][1] = cos(alpha_rad);  // ligne 2, col 2
  
  mulmat(m,a,b);

  printf("%lf %lf\n",b[0],b[1]);

  return return_code;
}










void   mulmat2(double m[][N],double a[],double b[]) {
  int l,c;
  for(l=0;l<M;l++) {
    b[l]=0.;
    for(c=0;c<N;c++) {
      b[l]+=m[l][c]*a[c];
    }
  }
  return;
}
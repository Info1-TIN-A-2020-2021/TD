/**
  \file      TD20201103b.c
  \brief     controle structure do/while loop
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-10-12 15:10:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <math.h>

// main: entry point of the software
int main(int argc, char const *argv[]) {

  int ret = 0;
  int32_t n = 0;

  do {

    printf("Enter an integer value  0< n <100: ");

    ret = scanf("%d", &n);
    
    // clean the keyboard buffer
    while(getchar()!='\n')
      ;
  
  } while (n<0 || n>=100 || ret!=1);

  printf("sqrt(%d)=%lf\n", n, sqrt(n));

  return 0;
}

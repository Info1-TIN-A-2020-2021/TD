/**
  \file      TD20200929b.c
  \brief     cylinder volume computation
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-09-29 15:10:00
  \details
    
**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdint.h> // library for standard types
#include <math.h>   // mathematic library

// main: entry point of the software
int main(int argc, char const *argv[])
{
  const double pi = 3.141592654;

  double height = 0.;
  double radius = 0.;
  double surface = 0.;
  double volume = 0.;

  printf("Enter the height of the cylinder in [m] (>0) : ");
  scanf("%lf", &height);

  printf("Enter the radius of the cylinder in [m] (>0) : ");
  scanf("%lf", &radius);

  surface = pi * pow(radius, 2.); // pow = power function (math.h required)
  volume = surface * height;

  printf("\nvolume = %.2lf [m3]\n", volume);

  return 0; // return code
}

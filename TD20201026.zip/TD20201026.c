/**
  \file      TD20201026.c
  \brief     controle structure if/else
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-10-12 15:10:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs

// main: entry point of the software
int main(int argc, char const *argv[]) {

  const double th1 = 0.;
  const double th2 = 50.;
  const double th3 = 1500.;
  const double th4 = 15000.;
  double voltage = 0.;
  int ret = 0;

  if(argc==1) { // interactive mode
    printf("Enter the voltage [V]: ");
    ret=scanf("%lf", &voltage);
  }
  else if(argc==2) {// non-interactive mode
    ret=sscanf(argv[1], "%lf", &voltage);
  }
  else {
    puts("Unknown mode.");
  }

  if(ret==1) {

    if(th1<voltage && voltage<=th2) {
      puts("BT");
    }
    else if(th2<voltage && voltage<=th3) {
      puts("MT");
    }
    else if(th3<voltage && voltage<=th4) {
      puts("HT");
    }
    else {
      puts("THT");
    }
  }


  return 0;
}

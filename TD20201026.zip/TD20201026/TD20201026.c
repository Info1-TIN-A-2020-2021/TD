/**
  \file      TD20201026.c
  \brief     controle structure if/else
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-10-12 15:10:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs

// main: entry point of the software
int main(int argc, char const *argv[]) {

  return 0;
}

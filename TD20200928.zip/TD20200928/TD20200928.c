/**
  \file      TD20200928.c
  \brief     Work on basics for new C file
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-09-28 13:30:25
  \details
    
**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdint.h> // library for standard types

// main: entry point of the software
int main(int argc, char const *argv[])
{

    int32_t x = 10; // declaration of x as an integer on 32bit and initialized to 10.
    int32_t y = 20;
    int32_t z = y - x;
    int32_t t = x + y;
    
    puts("Welcome."); // send the "Welcome." text to the terminal

    // display x, y, z and t to the terminal
    printf("x=%d\n", x);
    printf("y=%d\n", y);
    printf("z=%d\n", z);
    printf("t=%d\n", t);

    return 0; // return code
}

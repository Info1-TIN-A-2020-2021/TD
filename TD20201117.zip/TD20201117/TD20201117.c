/**
  \file      TD20201117.c
  \brief     1D table usage
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-17 14:55:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs
#include <math.h>

#define N 2000

int main(int argc, char const *argv[])
{
  double x[N];
  const double f = 1.;
  const double pi = 3.141592654;
  const double step = 0.001;
  uint32_t k = 0;
  double t = 0.;

  double max_value = 0.;
  uint32_t max_index = 0;

  printf("Size of x = %lu bytes.\n", sizeof(x));

  for (k = 0; k < N; k++) {
    // k : entier
    // step : double
    // k * step => promotion numérique de k en double => le résultat est un double.
    t = k * step;
    x[k] = sin(2. * pi * f * t);
  }
#if 0
  for (k = 0; k < N; k++) {
    printf("%4u  %+lf\n", k, x[k]);
  }
#endif

  // store the first value as the maximum and the related index
  max_index = 0;
  max_value = x[max_index];

  for (k = 1; k < N;k++) {
    if(x[k]>max_value) {
      max_value = x[k];
      max_index = k;
    }
  }
  printf("max value = %lf at index = %u\n", max_value, max_index);
  return 0;
}

// find and display the min value and related index
// should be : min value = -1.000000 at index = 750



#if 0

#define N 2000

// main: entry point of the software
int main(int argc, char const *argv[]) {

  const double f = 1.;
  const double pi = 3.141592654;
  const double step = 0.001;
  uint32_t k = 0;
  double t = 0.;
  double x[N] = {0.};
  double sum = 0.;
  double mean = 0.;
  double min_value = 0.;
  uint32_t min_index = 0;

  double max_value = 0.;
  uint32_t max_index = 0;

  double delta = 0.;
  double delta_max = 0.;
  uint32_t delta_max_index = 0;

  printf("size of x = %lu octets.\n", sizeof(x));


  for (k = 0; k < N; k++)
  {
    t = k * step;
    x[k] = sin(2. * pi * f * t);
  }

  for (k = 0; k < N; k++) {
    sum += x[k];
  }
  mean = sum / N;
  printf("mean=%lf\n", mean);

  // min, max and related indexes
  min_value = x[0];
  max_value = x[0];
  for (k = 1; k < N; k++)
  {
    if(x[k]<min_value) {
      min_value = x[k];
      min_index = k;
    }
    if(x[k]>max_value) {
      max_value = x[k];
      max_index = k;
    }
  }
  printf("min value=%lf at %u\n", min_value, min_index);
  printf("max value=%lf at %u\n", max_value, max_index);

  delta_max = x[1] - x[0];
  delta_max_index = 0;
  for (k = delta_max_index+1; k < N-1; k++) {
    delta = x[k + 1] - x[k];
    if(delta>delta_max) {
      delta_max = delta;
      delta_max_index = k;
    }
  }

  printf("max delta=%lf at %u\n", delta_max, delta_max_index);
  return 0;
}


#endif

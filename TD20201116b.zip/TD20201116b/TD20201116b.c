/**
  \file      TD20201116b.c
  \brief     simple table
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-09 15:10:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs

#define N 10    // table size

// main: entry point of the software
int main(int argc, char const *argv[]) {

  int32_t t[N];

  int32_t k = 0; // loop index

  // init t with odd values starting at 1
  for (k = 0; k < N;k++) {
    t[k] = 1 + 2 * k; // writing t[k]
  }


  // display t content
  for (k = 0; k < N; k++) {
    printf("t[%d]=%d\n", k, t[k]); // reading t[k]
  }

 
    return 0;
}

/**
  \file      TD20201012.c
  \brief     formats
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-10-12 15:10:00
  \details
    
**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdint.h> // library for standard types

// main: entry point of the software
int main(int argc, char const *argv[])
{
#if 0

  char c = 48; // 48 = ascii code of '0'
  // char c='0'; // same as char c = 48;

  uint32_t k = 38;
  int32_t i = 12;
  float f = 10.0f;
  double d = 10.0;
  char s[] = "OK";

  uint32_t hours = 8;
  uint32_t min = 7;
  uint32_t sec = 0;

  printf("Hello\n");       // \n : new line
  printf("\tHello\n");     // \t : tabulation 8 spaces
  printf("1234\tHello\n"); // \t : tabulation 8 spaces - alignment

  puts("Salut"); // \n is always included

  putchar('A');
  puts("");

  putchar(c);
  puts("");

  // -------

  printf("k=%u\n", k);
  printf("i=%d\n", i);
  printf("f=%f\n", f);
  printf("d=%lf\n", d);
  printf("c=%c\n", c); // display the char with ASCII code = c
  printf("s=%s\n", s);

  // -------

  printf("i=[%6d]\n", i);
  printf("i=[%-6d]\n", i);
  printf("i=[%+6d]\n", i);
  printf("i=[%+-6d]\n", i);
  printf("i=[%06d]\n", i);

  // -------

  printf("%02d:%02d:%02d\n", hours, min, sec);

  // -------

  //  w=5    [   12]           %5d
  //  w=10    [        12]     %10d

  int32_t w = 5;
  printf("i=[%*d]\n", w, i);
  w = 20;
  printf("i=[%*d]\n", w, i);

  // --------
  int32_t totalWidth = 10;
  int32_t numDec = 2;

  printf("[%*.*lf]\n", totalWidth, numDec, d);

  numDec = 4;
  printf("[%*.*lf]\n", totalWidth, numDec, d);


  // ----------
  int32_t j = 0;
  int ret = 0;

  printf("Entrez la valeur de i :");
  ret=scanf("%d", &i);
  printf("ret=%d\n", ret);
  printf("i=%d\n", i);
  
  printf("Entrez la valeur de j :");
  ret=scanf("%d", &j);
  printf("ret=%d\n", ret);
  printf("j=%d\n", j);

#endif

  double x = 0.;
  int ret = 0;

  printf("Entrez la valeur de x [0.0 à 10.0] : ");
  ret = scanf("%lf", &x);

  /*if (ret != 1)
  {
    puts("Erreur");
  }
  else
  {
    if (x < 0. || x > 10.)
    {
      puts("Erreur");
    }
    else
    {
      printf("OK, x=%lf\n", x);
    }
  }*/

  if (ret != 1 || x < 0. || x > 10.)
  {
    puts("Erreur");
  }
  else
  {
    printf("OK, x=%lf\n", x);
  }

  return 0;
}

/**
  \file      TD20201130.c
  \brief     fonction
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-30 14:55:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs
#include <math.h>

// prototype
double racine_cubique(double x);


// implementation
double racine_cubique(double x) {

  double result = 0.;

  // pow returns good value only if x>=0 ; use fabs() to compute the cubic root
  result = pow(fabs(x), 1. / 3.);

  // and adapt the result with the sign of x
  return x >= 0 ? result : -result;
}


int main(int argc, char const *argv[])
{
  const int NO_ERROR = 0;
  const int BAD_ARG = 1;
  const int CORRECT_NUM_ARGS = 2;
  int return_code = NO_ERROR;

  double z = 0.;
  double r = 0.;
  int ret = 0;

  if (argc == CORRECT_NUM_ARGS)
  {
    ret=sscanf(argv[1], "%lf", &z);
    if(ret==1) {

      r = racine_cubique(z);
      printf("%+lf\n", r);
    }
    else {
      return_code = BAD_ARG;
    }
  }
  else {
    return_code = BAD_ARG;
  }

  return return_code;
}

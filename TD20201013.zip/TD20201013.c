/**
  \file      TD20201013.c
  \brief     variable en mémoire
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-10-12 15:10:00
  \details
    
**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdint.h> // library for standard types

// main: entry point of the software
int main(int argc, char const *argv[])
{
#if 0  // set to 1 to enable the first exercise.

  uint16_t x = 0;
  uint16_t y = 0;
  uint16_t z = 0;
  uint16_t t = 0;
  int ret = 0;

  printf("x = %hu\n", x);
  printf("adress of x = %p\n", &x);  // &x : adress of variable x
  printf("adress of y = %p\n", &y);  
  printf("adress of z = %p\n", &z); 
  printf("adress of t = %p\n", &t);

  printf("Enter z: ");
  ret = scanf("%u", &z);
  printf("x = %hu\n", x);
  printf("y = %hu\n", y);
  printf("z = %hu\n", z);
  printf("t = %hu\n", t);

#else

  double w = 0.;
  int ret = 0;

  if (argc < 2)
  {
    puts("Error, not enough arguments.");
  }
  else {
    // sscanf
    //   1er arg : chaine de caractère
    //   2nd arg : format d'interprétation de la chaine
    //   3me arg : adresse de la variable à mettre à jour
    ret = sscanf(argv[1], "%lf", &w); 
    if(ret==1) {
      printf("w updated = %lf\n", w);
    }
    else {
      puts("Error, argv[1] has not the expected format (%lf).");
    }
  }

#endif

  return 0;
}

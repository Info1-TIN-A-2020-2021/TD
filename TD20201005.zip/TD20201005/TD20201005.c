/**
  \file      TD20201005.c
  \brief     types
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-10-05 15:10:00
  \details
    
**/

#include <stdio.h>  // standard library for inputs and ouputs
#include <stdint.h> // library for standard types
#include <math.h>   // mathematic library

// main: entry point of the software
int main(int argc, char const *argv[])
{
  uint8_t a = 100;
  uint8_t b = 3;
  uint16_t c = 0;
  uint8_t d = 0;

  c = a * b;
  d = a * b;
  
  return 0;
}

/**
  \file      TD20201123.c
  \brief     1D table usage
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-1723 14:55:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs

#define N 5

int main(int argc, char const *argv[])
{
  char t1[N] = { 1, 2, 3, 4, 5};
  char t2[N] = { 6, 7, 8, 9, 10};
  char t3[N] = { 11, 12, 13, 14, 15};
  
  int32_t k =0; // signed value

  for(k=0;k<N;k++) {
    printf("t1[%u]    %p   %d\n", k, &(t1[k]), t1[k]);
  }
  for(k=0;k<N;k++) {
    printf("t2[%u]    %p   %d\n", k, &(t2[k]), t2[k]);
  }
  for(k=0;k<N;k++) {
    printf("t3[%u]    %p   %d\n", k, &(t3[k]), t3[k]);
  }
  puts("------");
  k=0;
  t2[k-1]=42;

  k=N-1;
  t2[k+2]=99;

  for(k=0;k<N;k++) {
    printf("t1[%u]    %p   %d\n", k, &(t1[k]), t1[k]);
  }
  for(k=0;k<N;k++) {
    printf("t2[%u]    %p   %d\n", k, &(t2[k]), t2[k]);
  }
  for(k=0;k<N;k++) {
    printf("t3[%u]    %p   %d\n", k, &(t3[k]), t3[k]);
  }

  return 0;
}

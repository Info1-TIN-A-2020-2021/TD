/**
  \file      TD20201103.c
  \brief     controle structure while loop
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-10-12 15:10:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <math.h>

// main: entry point of the software
int main(int argc, char const *argv[]) {

  const double pi = 3.141592653589793;
  double p = 0.; // estimate of pi
  double error = 1e-6;
  uint32_t n = 1;
  int32_t s = +1;
  uint32_t maxNumIter = 10000;
  uint32_t numIter = 0;

  while (fabs(pi - p) >= error && numIter<maxNumIter)
  {
    numIter++;
    p += s * (4. / n);
    n += 2; //  1,  3,  5,  7...
    s = -s; // +1, -1, +1, -1...

  }
  printf("%6u  %+.10lf\n", numIter, p);
  return 0;
}

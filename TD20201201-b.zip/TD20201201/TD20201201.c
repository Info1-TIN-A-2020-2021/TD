/**
  \file      TD20201201.c
  \brief     fonction
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-30 14:55:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs

// prototypes
int32_t minimum(int32_t a, int32_t b);
int32_t min3(int32_t a, int32_t b, int32_t c);
int32_t median(int32_t a, int32_t b, int32_t c);

// implementation
int32_t median(int32_t a, int32_t b, int32_t c) {

  if( ( b<=a && a<=c) || (c<=a && a<=b) )
    return a;
  else if( (a<=b && b<=c) || (c<=b && b<=a) )
    return b;
  else
    return c;
}

int32_t min3(int32_t a, int32_t b, int32_t c) {

  return minimum(minimum(a, b), c);

}


int32_t minimum(int32_t a, int32_t b) {

  if(a<b) {
    return a;
  }
  else {
    return b;
  }

  // return a < b ? a : b;
}

int main(int argc, char const *argv[])
{
  const int NO_ERROR = 0;
  int return_code = NO_ERROR;

  int32_t x = 42;
  int32_t y = 27;
  int32_t t = 12;
  
  int32_t z = 0;

  puts("\n** minimum **");

  z = minimum(x, y);
  printf("x=%d\n", x);
  printf("y=%d\n", y);
  printf("z=%d\n", z);

  puts("\n** min3 **");

  z = min3(x, y, t);
  printf("x=%d\n", x);
  printf("y=%d\n", y);
  printf("t=%d\n", t);
  printf("z=%d\n", z);

  puts("\n** median **");
  z = median(x, y, t);
  printf("x=%d\n", x);
  printf("y=%d\n", y);
  printf("t=%d\n", t);
  printf("z=%d\n", z);

  return return_code;
}

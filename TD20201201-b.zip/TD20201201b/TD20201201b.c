/**
  \file      TD20201201b.c
  \brief     debug
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-30 14:55:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs


int main(int argc, char const *argv[])
{
  const int NO_ERROR = 0;
  int return_code = NO_ERROR;
  int k = 0;

  printf("argc=%d\n", argc);

  for (k = 0; k < argc;k++) {

    printf("argv[%d]=%s\n", k, argv[k]);
    
  }
  return return_code;
}

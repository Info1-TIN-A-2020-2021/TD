/**
  \file      TD20201116a.c
  \brief     bin2dec
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-09 15:10:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <math.h>

// main: entry point of the software
int main(int argc, char const *argv[]) {

  char c = 0;
  uint8_t i = 0;

  printf("Enter a binary value: ");

  // 11001010
  // c=getchar() => premier '1'

  do {
    c = getchar();

    if(c=='0' || c=='1') {
      i <<= 1; // i = i << 1;
      i += c - '0';
    }
    else {
      // error case
    }

  } while (c != '\n');

  printf("i=%u\n", i);

  puts("");
  return 0;
}

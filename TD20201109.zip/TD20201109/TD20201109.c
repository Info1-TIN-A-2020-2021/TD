/**
  \file      TD20201109.c
  \brief     controle structure do/while loop
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-10-12 15:10:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>
#include <math.h>

// main: entry point of the software
int main(int argc, char const *argv[]) {

  int32_t cpt = 0;

  for (cpt = 1; cpt <= 100; cpt++) {
    // test is cpt is even
#if 0
    // option 1: cpt modulo 2 == 0 => even
    if(cpt%2==0) {
      printf("%4d", cpt);
    }
#else
    // option 2: LSB value is zero: logical AND with mask=00000000001
    if( (cpt&1)==0 ) {
      printf("%4d", cpt);
    }
#endif

  /* alternative
    for (cpt = 2; cpt <= 100; cpt=cpt+2) {
      printf("%4d", cpt);
    }
  }*/
  puts("");
  return 0;
}

/**
  \file      TD20210104.c
  \brief     tri de tableau
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-30 14:55:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs

#define N 4

int main(int argc, char const *argv[])
{
  const int NO_ERROR = 0;
  int return_code=NO_ERROR;

  char t[N] = {12, 4, 1, 7};
  char tmp = 0;

  uint32_t i = 0;
  uint32_t j = 0;

  // display the table content
  for (i = 0; i < N;i++) {
    printf("%4d", t[i]);
  }
  puts("");

  // sort the table
  for (i = 0; i < N-1;i++) {
    for (j = i + 1; j < N;j++) {
      if(t[j]<t[i]) { // need to swap t[i] <-> t[j]
        tmp = t[i];
        t[i] = t[j];
        t[j] = tmp;
      }
    }
  }

  // display the table content
  for (i = 0; i < N;i++) {
    printf("%4d", t[i]);
  }
  puts("");




  return return_code;
}

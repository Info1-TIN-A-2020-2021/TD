/**
  \file      TD20201214.c
  \brief     adress
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-30 14:55:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs

void minmax(const int16_t a, const int16_t b, int16_t *minimum, int16_t *maximum);
void minmax(const int16_t a, const int16_t b, int16_t *minimum, int16_t *maximum) {

  printf("\nMINMAX, begining of function\na=%hd\n",a);
  printf("b=%hd\n",b);
  printf("minimum=%p\n",minimum);
  printf("maximum=%p\n",maximum);

  *minimum = a<b ? a : b;
  *maximum = a>=b ? a : b;

  printf("\nMINMAX, end of function\na=%hd\n",a);
  printf("b=%hd\n",b);
  printf("minimum=%p\n",minimum);
  printf("maximum=%p\n",maximum);

  return;
}


int main(int argc, char const *argv[])
{
  const int NO_ERROR = 0;
  int return_code=NO_ERROR;

  int16_t x=12;
  int16_t y=15;
  int16_t min=0;
  int16_t max=0;
  
  printf("\nMAIN, before function call...\nx=%hd\n",x);
  printf("y=%hd\n",y);
  printf("min=%hd\n",min);
  printf("max=%hd\n",max);
  printf("&min=%p\n",&min);
  printf("&max=%p\n",&max);

  minmax(x,y,&min,&max);

  printf("\nMAIN, after function call...\nx=%hd\n",x);
  printf("y=%hd\n",y);
  printf("min=%hd\n",min);
  printf("max=%hd\n",max);
  printf("&min=%p\n",&min);
  printf("&max=%p\n",&max);

  return return_code;
}






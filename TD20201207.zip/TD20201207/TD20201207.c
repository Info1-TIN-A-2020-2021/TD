/**
  \file      TD20201207.c
  \brief     rotation matrix
  \author    Pierre BRESSY
  \version   1.0
  \date      2020-11-30 14:55:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs
#include <math.h>

#define M 2
#define N 2


int main(int argc, char const *argv[])
{
  const int NO_ERROR = 0;
  int return_code = NO_ERROR;

  double xa = 1.;
  double ya = 0.;
  double alpha = 45.;
  double alpha_rad = alpha / 180 * 3.141592654;
  double xb = 0.;
  double yb = 0.;

  double a[M] = {0,0};
  double b[M] = {0,0};
  double m[M][N] = {
      {0,0},
      {0,0}
  };

  printf("xa=%+6.3lf ya=%+6.3lf\n", xa, ya);
  xb = xa * cos(alpha_rad) - ya * sin(alpha_rad);
  yb = xa * sin(alpha_rad) + ya * cos(alpha_rad);
  printf("xb=%+6.3lf yb=%+6.3lf\n", xb, yb);

  a[0] = xa;
  a[1] = ya;
  m[0][0] = cos(alpha_rad);  // ligne 1, col 1
  m[0][1] = -sin(alpha_rad); // ligne 1, col 2
  m[1][0] = sin(alpha_rad);  // ligne 2, col 1
  m[1][1] = cos(alpha_rad);  // ligne 2, col 2
  
  return return_code;
}

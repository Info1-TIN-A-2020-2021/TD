/**
  \file      TD20210111.c
  \brief     tri de tableau 2D
  \author    Pierre BRESSY
  \version   1.0
  \date      2021-01-11 13:55:00
  \details

**/

#include <stdint.h> // library for standard types
#include <stdio.h>  // standard library for inputs and ouputs
#include <stdlib.h>  // standard library for rand
#include <time.h>  // library for time()

#define H 3
#define W 4

void init_table(uint8_t t[][W], const uint32_t rows);



void init_table(uint8_t t[][W], const uint32_t rows)
{
  uint32_t row = 0; // index on lines
  uint32_t col = 0; // index on columns

  // init t with random numbers between 0 and 99
  for (row = 0; row < rows; row++) {
    for (col = 0; col < W; col++) {

      // function to generate a random number: rand()   => 0..RAND_MAX
      // to reduce [0..RAND_MAX] to [0..100[ : modulo 100

      t[row][col] = rand() % 100; // [0..99]
    }
  }
  return;
}

void display_table(uint8_t t[][W], const uint32_t rows)
{
  uint32_t row = 0; // index on lines
  uint32_t col = 0; // index on columns

  // init t with random numbers between 0 and 99
  for (row = 0; row < rows; row++) {
    for (col = 0; col < W; col++) {

      printf("%4u", t[row][col]);
    }
    puts("");
  }
  return;
}

int main(int argc, char const *argv[])
{
  const int NO_ERROR = 0;
  int return_code=NO_ERROR;

  uint8_t t[H][W] = {0};

  // init the seed of the random number generator
  srand((unsigned int)time(NULL));

  init_table(t, H);

  display_table(t, H);

  return return_code;
}
